<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CM Commission Management Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
    <style>
        body {
            background-color: #f7f9fc;
            font-family: 'Roboto', sans-serif;
        }

 
.sidebar {
    height: 100vh;
    width: 250px;
    background: linear-gradient(145deg, #0f2027, #203a43, #f20f79);
    position: fixed;
    top: 0;
    left: 0;
    padding: 60px 20px;
    font-size: 17px;
    box-shadow: 2px 0 15px rgba(0, 0, 0, 0.5);
    transition: width 0.3s ease-in-out;
    overflow: hidden;
}
 
.sidebar h4 {
    color: #ffffff;
    text-align: center;
    margin-bottom: 30px;
    font-size: 28px;
    font-weight: bold;
    letter-spacing: 1px;
}

.sidebar a {
    color: #ffffff;
    text-decoration: none;
    display: flex;
    align-items: center;
    margin: 15px 0;
    padding: 7px;
    border-radius: 8px;
    transition: background 0.3s ease, transform 0.3s ease;
    font-size: 18px;
    letter-spacing: 0.5px;
}

.sidebar a i {
    margin-right: 10px;
    font-size: 20px;
    transition: transform 0.3s;
}

.sidebar a:hover {
    background: rgba(255, 255, 255, 0.1);
    box-shadow: 0 0 15px rgba(255, 255, 255, 0.3);
    transform: translateX(10px);
}

.sidebar a:hover i {
    transform: rotate(360deg);
}

body {
    background: radial-gradient(circle at top left, #1e3c72, #2a5298);
    color: #fff;
    font-family: 'Poppins', sans-serif;
}


        .main-content {
            margin-left: 260px;
            padding: 20px;
        }

        .container {
            /* margin-top: 30px; */
            background: #ffffff;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
        }

        h1 {
            color: #007bff;
            margin-bottom: 20px;
            text-align: center;
            font-weight: bold;
            background: linear-gradient(90deg, #007bff, #6610f2);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .input-group {
            position: relative;
            margin-bottom: 20px;
        }

        .search-input {
            border: 2px solid #007bff;
            border-radius: 30px;
            padding: 10px 20px;
            transition: border-color 0.3s;
        }

        .search-input:focus {
            border-color: #0056b3;
            outline: none;
        }



        .search-button {
            position: absolute;
            right: 0;
            top: 0;
            bottom: 0;
            border: none;
            background-color: #007bff;
            color: white;
            border-radius: 30px;
            padding: 0 20px;
            transition: background-color 0.3s, transform 0.3s;
            display: flex;
            align-items: center;
        }

        .search-button:hover {
            background-color: #0056b3;
            transform: scale(1.05);
        }
        

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        th,td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
            vertical-align: middle;
        }

        th {
            background-color: #007bff;  
            color: white;
            font-weight: bold;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:nth-child(odd) {
            background-color: #ffffff;
        }

        tr:hover {
            background-color: #d1ecf1;
        }

        .details-row {
            display: none;
        }

        .btn-info {
            transition: all 0.3s;
            background-color: #007bff;
            border: none;
            border-radius: 5px;
            color: white;
            padding: 8px 12px;
        }

        .btn-info:hover {
            transform: translateY(-2px);
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
            background-color: #0056b3;
        }

        .no-data {
            text-align: center;
            color: #dc3545;
            font-style: italic;
            margin-top: 20px;
        } 

        @media (max-width: 768px) {
            .sidebar {
                width: 200px;
            }

            .main-content {
                margin-left: 210px;
            }

            table {
                font-size: 12px;
            }
        }


        .table thead th {
            background-color: #007bff;
            color: white;
            position: sticky;
            top: 0;
        }

        @media (max-width: 576px) {
            .sidebar {
                display: none;
            }

            .main-content {
                margin-left: 0;
                padding: 10px;
            }

            h1 {
                font-size: 1.5em;
            }
        }

        table{
            font-size: 15px;
        }

    .colorful-text {
        background: linear-gradient(90deg, #f5075af9, #025b1e, #1342eaf9, #e18215);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        font-size: 3em;
        text-align: center;
        font-weight: 900;
        padding-bottom: 30px;
        font-weight: bold;
        font-weight: 900;
        text-align: center;
        animation: gradient-animation 5s ease-in-out infinite;
    }

/* Optional: Add animation for a dynamic gradient effect */
@keyframes gradient-animation {
    0% {
        background-position: 0% 50%;
    }
    100% {
        background-position: 100% 50%;
    }
}




body {
    margin: auto;
    font-family: -apple-system, BlinkMacSystemFont, sans-serif;
    overflow: auto;
    background: linear-gradient(315deg, rgb(100, 1, 94) 10%, rgba(0, 123, 255,1) 58%, rgba(242, 15, 121,1) 68%, rgba(15, 32, 39,1) 98%);
    animation: gradient 40s ease infinite;
    background-size: 210% 210%;
    background-attachment: fixed;
    
}

@keyframes gradient {
    0% {
        background-position: 0% 0%;
    }
    50% {
        background-position: 100% 100%;
    }
    100% {
        background-position: 0% 0%;
    }
}

.wave {
    background: rgb(255 255 255 / 25%);
    border-radius: 1000% 1000% 0 0;
    position: fixed;
    width: 200%;
    height: 12em;
    animation: wave 10s -3s linear infinite;
    transform: translate3d(0, 0, 0);
    opacity: 0.8;
    bottom: 0;
    left: 0;
    z-index: -1;
}

.wave:nth-of-type(2) {
    bottom: -1.25em;
    animation: wave 18s linear reverse infinite;
    opacity: 0.8;
}

.wave:nth-of-type(3) {
    bottom: -2.5em;
    animation: wave 20s -1s reverse infinite;
    opacity: 0.9;
}

@keyframes wave {
    2% {
        transform: translateX(1);
    }

    25% {
        transform: translateX(-25%);
    }

    50% {
        transform: translateX(-50%);
    }

    75% {
        transform: translateX(-25%);
    }

    100% {
        transform: translateX(1);
    }
}

.control-center-heading {
        color: #8f8d8d;
        text-align: center;
        font-size: 18px;
        font-weight: 500;
        padding: 10px 10px;
        margin-bottom: 20px;
        margin-top: 30px;
        background: linear-gradient(145deg, #0f2027, #203a43,#0f2027);
        border-radius: 8px;
        box-shadow: 0px 4px 6px rgba(75, 74, 74, 0.3);
        text-transform: uppercase;
        letter-spacing: 1.5px;
    }


    .input-group {
    max-width: 800px; /* Adjust width as needed */
    margin: 0 auto;   /* Center align the input group */
}


.search-button {
    border-radius: 0 25px 25px 0;  /* Rounded corners for the button */
    background-color: #007bff;     /* Button background color */
    color: white;                   /* Button text color */
    border: 1px solid #007bff;      /* Match border with background */
    transition: background-color 0.2s ease; /* Smooth transition for hover effect */
}

.search-button:hover {
    background-color: #0056b3;      /* Darker shade on hover */
    border-color: #0056b3;          /* Match border with hover color */
}

.search-button i {
    font-size: 18px;                 /* Icon size */
}

.search-input {
    border-radius: 25px 0 0 25px; /* Rounded corners for the input */
    border: 1px solid #007bff;     /* Change border color */
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* Subtle shadow effect */
    font-size: 16px;                /* Increase font size for readability */
    padding: 10px 25px;   
    border-width: 1.8px;
}          /* Add padding for better spacing */
}

.search-input::placeholder {
    color: #aaa;                    /* Lighter color for the placeholder */
    opacity: 1;                     /* Make it fully opaque */
    transition: color 0.3s ease;   /* Smooth transition for color change */
}

.search-input:focus::placeholder {
    color: #007bff;                 /* Change color on focus to match input */
    opacity: 0.7;                   /* Slightly reduce opacity on focus */
}


.total-row {
    font-weight: bold;
    color: white;
    background-color: #2c4e72;

}

.total-row td {
    text-align: left;
    background: #fb478c;
    color: white;
}
.dashboard-container {
            max-width: 1200px; /* Increased max width for better layout */
            margin: auto;
            padding: 20px;
            border-radius: 10px;
            background-color: rgba(255, 255, 255, 0.9); /* Slight background to make it pop */
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }
        .phase-card {
            background: #fff;
            border-radius: 20px;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-bottom: 30px;
            transition: transform 0.3s, box-shadow 0.3s;
            overflow: hidden;
            position: relative;
        }
        .phase-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 12px 24px rgba(0, 0, 0, 0.2);
        }
        .phase-header {
            font-size: 1.5em;
            font-weight: bold;
            margin-bottom: 10px;
            color: #6a11cb; /* Color change for better visibility */
        }
        .phase-header span {
            background: linear-gradient(45deg, #ff416c, #ff4b2b);
            color: #fff;
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 0.9em;
        }
        .icon {
            font-size: 4em; /* Slightly larger icons */
            margin-bottom: 15px;
            color: #2575fc;
            transition: transform 0.3s;
        }
        .phase-description {
            font-size: 1em;
            color: #666;
            margin-bottom: 15px;
        }
        .btn-details {
            background: #2575fc;
            color: #fff;
            border: none;
            border-radius: 5px;
            padding: 10px 20px; /* Increased padding */
            font-size: 1em;
            transition: background 0.3s, transform 0.3s;
        }
        .btn-details:hover {
            background: #6a11cb;
            transform: scale(1.05);
        }
        .main-title {
            text-align: center;
            color: #ffffff25;
            font-weight: 700;
            font-size: 3em; /* Increased title size */
            margin-bottom: 50px;
            text-shadow: 2px 2px 4px rgba(251, 248, 248, 0.2);
        }

/* .phase-card.dimmed {
    opacity: 0.5; 
    pointer-events: none; 
    filter: grayscale(10%); 
}
.colorful-text {
    color: #b3dbf6; 
    text-shadow: 1px 1px 4px rgba(255, 253, 253, 0.07);
} */

.sidebar a {
    color: #ffffff;
    text-decoration: none;
    display: flex;
    align-items: center;
    margin: 10px 0;
    padding: 7px;
    border-radius: 8px;
    transition: background 0.3s ease, transform 0.3s ease;
    font-size: 18px;
    letter-spacing: 0.6px;
}
    </style>
</head>
<body>

    <div class="wave"></div>
    <div class="wave"></div>
    <div class="wave"></div>
  
    <div class="sidebar" style="background-color: #2c3e50; padding-left: 20px; padding-top: 2px; height: 100vh; color: white;">
        <a style="padding-left:55px; padding-bottom:0px;" class="navbar-brand" href="/">
            <img src="{{ asset('storage/images/newlogo.png') }}" alt="Logo" width="100">
        </a>
        <div style="color: #9f9f9f; text-align:center; font-size:15px"><i > New Thinking New Way</i> </div>
        <hr style="border-top: 1px solid #fdfeff; width: 100%;">

        <h5 class="control-center-heading" style="margin-top: 20px">Quick Access</h5>
        {{-- <a href="/import-data" style="color: #ecf0f1; display: block; margin-bottom: 16px;">
            <i class="fas fa-home" style="color: #3498db;"></i>  HOME
        </a> --}}
        <a href="/search" style="color: #ecf0f1; display: block;">
            <i class="fas fa-search-dollar fa-lg" style="color: #e67e22; margin-right: 8px;"></i> BM + CM + CIR <!-- Orange -->
        </a>

        <a href="/stop-payments" style="color: #ecf0f1; display: block;">
            <i class="fas fa-hand-paper fa-lg" style="color: #c0392b; margin-right: 8px;"></i> Stop Payment <!-- Dark Red -->
        </a>
        <a href="/recoveries" style="color: #ecf0f1; display: block;">
            <i class="fas fa-wallet fa-lg" style="color: #2ecc71; margin-right: 8px;"></i> Recovery Report <!-- Green -->
        </a>

        <a href="/commission" style="color: #ecf0f1; display: block;" >
            <i class="fas fa-chart-line fa-lg" style="color: #e74c3c; margin-right: 8px;" ></i> CM Commission <!-- Red -->
        </a>
        
        <a href="/import" style="color: #ecf0f1; display: block; margin-left:-3px">
            <i class="fas fa-balance-scale fa-lg" style="color: #f1c40f; margin-right: 10px;"></i>CIR Commission <!-- Yellow -->
        </a>
        <a href="/import-export" style="color: #ecf0f1; display: block;">
            <i class="fas fa-user-tie fa-lg" style="color: #3498db; margin-right: 8px;"></i> BM Commission <!-- Blue -->
        </a>
        
        <a href="/brokers" style="color: #ecf0f1; display: block; margin-left:-2px">
            <i class="fas fa-user-friends fa-lg" style="color: #8e44ad; margin-right: 10px;"></i>Broker Register <!-- Purple -->
        </a>
        
        <a href="/coming1" style="color: #ecf0f1; display: block;">
            <i class="fas fa-sliders-h fa-lg" style="color: #f39c12; margin-right: 8px;"></i> Control Panel
        </a>
 
        <a href="/login" style="color: #ecf0f1; display: block;">
            <i class="fas fa-sign-out-alt fa-lg" style="color: #16a085; margin-right: 8px;"></i> Logout <!-- Teal -->
        </a>
    </div> 
    
    <div class="main-content"> 
        <div class="container">
            <h1 class="colorful-text">MANAGE COMMISSION REPORTS</h1>
    <div class="container dashboard-container">
        <div class="row">
            <!-- Phase 01 -->
            <div class="col-md-4 col-sm-6">
                <div class="phase-card">
                    <div class="phase-header">
                        <span>TASK 01</span> CM-COMMISSION
                    </div>
                    <div class="icon">💰</div> <!-- Changed to a money bag icon -->
                    <button class="btn-details" onclick="window.location.href='/import-cm'">View Details</button>
                </div>
            </div>

            <!-- TASK 02 -->
            <div class="col-md-4 col-sm-6">
                <div class="phase-card">
                    <div class="phase-header">
                        <span>TASK 02</span> BM-COMMISSION
                    </div>
                    <div class="icon">📊</div> <!-- Changed to a bar chart icon -->
                    <button class="btn-details" onclick="window.location.href='/import-bm'">View Details</button>
                </div>
            </div>

            <!-- Phase 03 -->
            <div class="col-md-4 col-sm-6">
                <div class="phase-card">
                    <div class="phase-header">
                        <span>TASK 03</span> CIR-COMMISSION
                    </div>
                    <div class="icon">📈</div> <!-- Changed to a line graph icon -->
                    <button class="btn-details" onclick="window.location.href='/import-cir'">View Details</button>
                </div>
            </div>

           <!-- Phase 04 -->
<div class="col-md-4 col-sm-6">
    <div class="phase-card dimmed">
        <div class="phase-header">
            <span>TASK 04</span> BROKER REG
        </div>
        <div class="icon">📝</div>
        <button class="btn-details" onclick="window.location.href='/brokers'">View Details</button>
    </div>
</div>

<!-- Phase 05 -->
<div class="col-md-4 col-sm-6">
    <div class="phase-card dimmed">
        <div class="phase-header">
            <span>TASK 05</span> RECOVERY FILE
        </div>
        <div class="icon">📂</div>
        <button class="btn-details" onclick="window.location.href='/recoveries'">View Details</button>
    </div>
</div>

<!-- Phase 06 -->
<div class="col-md-4 col-sm-6">
    <div class="phase-card dimmed">
        <div class="phase-header">
            <span>TASK 06</span> STOP PAYMENTS
        </div>
        <div class="icon">🚫</div>
        <button class="btn-details" onclick="window.location.href='/stop-payments'">View Details</button>
    </div>
</div>

        </div>
    </div>

    <!-- Include Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
 